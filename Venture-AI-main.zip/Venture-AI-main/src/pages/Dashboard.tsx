import React, { useState } from 'react';
import { IdeaInputForm } from '../components/IdeaInputForm';
import { IdeaCard } from '../components/IdeaCard';
import { generateSaaSIdeas, GeneratedIdea } from '../lib/ai';
import { motion } from 'motion/react';
import { AlertCircle } from 'lucide-react';

export function Dashboard() {
  const [isLoading, setIsLoading] = useState(false);
  const [ideas, setIdeas] = useState<GeneratedIdea[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async (data: { skills: string; interest: string; audience: string; problems: string }) => {
    setIsLoading(true);
    setError(null);
    try {
      const generatedIdeas = await generateSaaSIdeas(data.skills, data.interest, data.audience, data.problems);
      setIdeas(generatedIdeas);
    } catch (err) {
      console.error(err);
      setError('Market data unavailable, try again. Please ensure your inputs are specific enough.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-8 max-w-6xl mx-auto min-h-full">
      <div className="mb-12">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">SaaS Idea Generator</h1>
        <p className="text-zinc-400">Validate your next big idea with real market data and financial projections.</p>
      </div>

      {error && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 p-4 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-center gap-3 text-rose-400"
        >
          <AlertCircle className="w-5 h-5" />
          <p className="text-sm font-medium">{error}</p>
        </motion.div>
      )}

      {ideas.length === 0 ? (
        <IdeaInputForm onSubmit={handleGenerate} isLoading={isLoading} />
      ) : (
        <div className="space-y-12">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-semibold text-zinc-100">Generated Ideas</h2>
            <button 
              onClick={() => setIdeas([])}
              className="text-sm font-medium text-zinc-400 hover:text-zinc-200 transition-colors"
            >
              Start Over
            </button>
          </div>
          
          <div className="grid grid-cols-1 gap-8">
            {ideas.map((idea, index) => (
              <IdeaCard key={index} idea={idea} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
