import React, { useEffect, useState } from 'react';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { IdeaCard } from '../components/IdeaCard';
import { GeneratedIdea } from '../lib/ai';
import { Loader2, BookmarkX } from 'lucide-react';

export function SavedIdeas() {
  const { user } = useAuth();
  const [ideas, setIdeas] = useState<GeneratedIdea[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchIdeas = async () => {
      if (!user) return;
      try {
        const q = query(
          collection(db, 'ideas'),
          where('userId', '==', user.uid),
          orderBy('createdAt', 'desc')
        );
        const snapshot = await getDocs(q);
        const fetchedIdeas = snapshot.docs.map(doc => ({
          ...doc.data()
        })) as GeneratedIdea[];
        setIdeas(fetchedIdeas);
      } catch (error) {
        console.error('Error fetching saved ideas:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchIdeas();
  }, [user]);

  return (
    <div className="p-8 max-w-6xl mx-auto min-h-full">
      <div className="mb-12">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Saved Ideas</h1>
        <p className="text-zinc-400">Review and export your previously generated SaaS ideas.</p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
        </div>
      ) : ideas.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-64 bg-zinc-900/50 border border-zinc-800/50 rounded-2xl border-dashed">
          <BookmarkX className="w-12 h-12 text-zinc-600 mb-4" />
          <h3 className="text-lg font-medium text-zinc-300 mb-1">No saved ideas yet</h3>
          <p className="text-sm text-zinc-500">Generate some ideas and save them to see them here.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-8">
          {ideas.map((idea, index) => (
            <IdeaCard key={index} idea={idea} isSaved={true} />
          ))}
        </div>
      )}
    </div>
  );
}
