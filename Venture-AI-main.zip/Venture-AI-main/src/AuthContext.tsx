import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { auth, db } from './firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  subscriptionTier: 'free' | 'pro';
}

const AuthContext = createContext<AuthContextType>({ user: null, loading: true, subscriptionTier: 'free' });

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [subscriptionTier, setSubscriptionTier] = useState<'free' | 'pro'>('free');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // Check if user document exists, if not create it
        const userRef = doc(db, 'users', currentUser.uid);
        const userSnap = await getDoc(userRef);
        
        if (!userSnap.exists()) {
          await setDoc(userRef, {
            email: currentUser.email,
            subscriptionTier: 'free',
            createdAt: new Date()
          });
          setSubscriptionTier('free');
        } else {
          setSubscriptionTier(userSnap.data().subscriptionTier || 'free');
        }
      } else {
        setSubscriptionTier('free');
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, subscriptionTier }}>
      {children}
    </AuthContext.Provider>
  );
};
