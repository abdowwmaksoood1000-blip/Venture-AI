import React, { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { Bookmark, Download, ExternalLink, TrendingUp, Users, Target, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { FinancialChart } from './FinancialChart';
import { GeneratedIdea } from '../lib/ai';
import { cn } from '../lib/utils';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { toPng } from 'html-to-image';
import { jsPDF } from 'jspdf';

interface IdeaCardProps {
  idea: GeneratedIdea;
  isSaved?: boolean;
}

export const IdeaCard: React.FC<IdeaCardProps> = ({ idea, isSaved = false }) => {
  const { user } = useAuth();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(isSaved);
  const [exporting, setExporting] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(value);
  };

  const getScoreColor = (score: number) => {
    if (score >= 70) return 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20';
    if (score >= 40) return 'text-amber-400 bg-amber-400/10 border-amber-400/20';
    return 'text-rose-400 bg-rose-400/10 border-rose-400/20';
  };

  const handleSave = async () => {
    if (!user || saved || saving) return;
    setSaving(true);
    try {
      const ideaId = crypto.randomUUID();
      await setDoc(doc(db, 'ideas', ideaId), {
        userId: user.uid,
        ...idea,
        createdAt: new Date()
      });
      setSaved(true);
    } catch (error) {
      console.error('Error saving idea:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleExportPDF = async () => {
    if (!cardRef.current || exporting) return;
    setExporting(true);
    try {
      const imgData = await toPng(cardRef.current, {
        quality: 1,
        pixelRatio: 2,
        backgroundColor: '#18181b', // zinc-900 background
      });
      
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'px',
        format: [cardRef.current.offsetWidth, cardRef.current.offsetHeight]
      });
      
      pdf.addImage(imgData, 'PNG', 0, 0, cardRef.current.offsetWidth, cardRef.current.offsetHeight);
      pdf.save(`${idea.title.replace(/\s+/g, '-').toLowerCase()}-ventureai.pdf`);
    } catch (error) {
      console.error('Error exporting PDF:', error);
    } finally {
      setExporting(false);
    }
  };

  return (
    <motion.div 
      ref={cardRef}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl"
    >
      <div className="p-6 border-b border-zinc-800">
        <div className="flex justify-between items-start gap-4 mb-4">
          <div>
            <h3 className="text-xl font-bold text-zinc-100 mb-1">{idea.title}</h3>
            <p className="text-sm text-zinc-400">{idea.pitch}</p>
          </div>
          <div className={cn("px-3 py-1 rounded-full border text-sm font-bold flex items-center gap-1.5 whitespace-nowrap", getScoreColor(idea.metrics.overall))}>
            {idea.metrics.overall >= 70 ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            {idea.metrics.overall} / 100
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mt-6">
          <div className="bg-zinc-950 rounded-xl p-4 border border-zinc-800/50">
            <div className="flex items-center gap-2 text-zinc-400 mb-1">
              <TrendingUp className="w-4 h-4" />
              <span className="text-xs font-medium uppercase tracking-wider">Demand</span>
            </div>
            <div className="text-2xl font-bold text-zinc-100">{idea.metrics.demand}</div>
          </div>
          <div className="bg-zinc-950 rounded-xl p-4 border border-zinc-800/50">
            <div className="flex items-center gap-2 text-zinc-400 mb-1">
              <Target className="w-4 h-4" />
              <span className="text-xs font-medium uppercase tracking-wider">Competition</span>
            </div>
            <div className="text-2xl font-bold text-zinc-100">{idea.metrics.competition}</div>
          </div>
          <div className="bg-zinc-950 rounded-xl p-4 border border-zinc-800/50">
            <div className="flex items-center gap-2 text-zinc-400 mb-1">
              <Users className="w-4 h-4" />
              <span className="text-xs font-medium uppercase tracking-wider">Feasibility</span>
            </div>
            <div className="text-2xl font-bold text-zinc-100">{idea.metrics.feasibility}</div>
          </div>
        </div>
      </div>

      <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div>
            <h4 className="text-sm font-semibold text-zinc-100 uppercase tracking-wider mb-2">The Problem</h4>
            <p className="text-sm text-zinc-400 leading-relaxed">{idea.problem}</p>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-zinc-100 uppercase tracking-wider mb-2">The Solution</h4>
            <p className="text-sm text-zinc-400 leading-relaxed">{idea.solution}</p>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-zinc-100 uppercase tracking-wider mb-2">Target Audience</h4>
            <p className="text-sm text-zinc-400 leading-relaxed">{idea.targetAudience}</p>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-zinc-100 uppercase tracking-wider mb-2">Monetization</h4>
            <p className="text-sm text-zinc-400 leading-relaxed">{idea.monetization}</p>
          </div>
        </div>

        <div className="bg-zinc-950 rounded-xl p-6 border border-zinc-800/50 flex flex-col">
          <h4 className="text-sm font-semibold text-zinc-100 uppercase tracking-wider mb-4 flex items-center justify-between">
            Financial Projections
            <span className="text-xs font-normal text-zinc-500 normal-case">AI Estimates Based on Market Models</span>
          </h4>
          
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div>
              <p className="text-xs text-zinc-500 mb-1">Est. MRR Range</p>
              <p className="text-lg font-bold text-indigo-400">
                {formatCurrency(idea.financials.mrrLow)} - {formatCurrency(idea.financials.mrrHigh)}
              </p>
            </div>
            <div>
              <p className="text-xs text-zinc-500 mb-1">Est. ARR Potential</p>
              <p className="text-lg font-bold text-emerald-400">
                {formatCurrency(idea.financials.arr)}
              </p>
            </div>
            <div>
              <p className="text-xs text-zinc-500 mb-1">Suggested Pricing</p>
              <p className="text-sm font-medium text-zinc-300">{formatCurrency(idea.financials.pricing)}/mo</p>
            </div>
            <div>
              <p className="text-xs text-zinc-500 mb-1">Est. TAM</p>
              <p className="text-sm font-medium text-zinc-300">{idea.financials.tam.toLocaleString()} users</p>
            </div>
          </div>

          <div className="flex-1 min-h-[200px]">
            <FinancialChart mrrLow={idea.financials.mrrLow} mrrHigh={idea.financials.mrrHigh} />
          </div>
        </div>
      </div>

      <div className="p-4 bg-zinc-950 border-t border-zinc-800 flex items-center justify-between">
        <div className="flex gap-3">
          <button 
            onClick={handleSave}
            disabled={saved || saving}
            className="flex items-center gap-2 px-4 py-2 bg-zinc-800 hover:bg-zinc-700 disabled:bg-zinc-800 disabled:opacity-50 text-zinc-100 rounded-lg text-sm font-medium transition-colors"
          >
            <Bookmark className={cn("w-4 h-4", saved && "fill-current text-indigo-400")} />
            {saved ? 'Saved' : saving ? 'Saving...' : 'Save Idea'}
          </button>
          <button 
            onClick={handleExportPDF}
            disabled={exporting}
            className="flex items-center gap-2 px-4 py-2 bg-zinc-800 hover:bg-zinc-700 disabled:bg-zinc-800 disabled:opacity-50 text-zinc-100 rounded-lg text-sm font-medium transition-colors"
          >
            {exporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            {exporting ? 'Exporting...' : 'Export PDF'}
          </button>
        </div>
        <a 
          href="https://lovable.dev" 
          target="_blank" 
          rel="noreferrer"
          className="flex items-center gap-2 px-6 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-medium transition-colors"
        >
          Build This
          <ExternalLink className="w-4 h-4" />
        </a>
      </div>
    </motion.div>
  );
}
