import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface FinancialChartProps {
  mrrLow: number;
  mrrHigh: number;
}

export const FinancialChart: React.FC<FinancialChartProps> = ({ mrrLow, mrrHigh }) => {
  const data = [
    { name: 'Month 1', mrr: mrrLow * 0.1 },
    { name: 'Month 3', mrr: mrrLow * 0.3 },
    { name: 'Month 6', mrr: mrrLow * 0.6 },
    { name: 'Month 9', mrr: mrrLow * 0.8 },
    { name: 'Month 12', mrr: mrrLow },
    { name: 'Year 2', mrr: mrrHigh },
  ];

  const formatCurrency = (value: number) => {
    if (value >= 1000) {
      return `$${(value / 1000).toFixed(1)}k`;
    }
    return `$${value.toFixed(0)}`;
  };

  return (
    <div className="h-64 w-full mt-4">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
          <XAxis 
            dataKey="name" 
            stroke="#71717a" 
            fontSize={12} 
            tickLine={false}
            axisLine={false}
          />
          <YAxis 
            stroke="#71717a" 
            fontSize={12} 
            tickFormatter={formatCurrency}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip 
            cursor={{ fill: '#27272a', opacity: 0.4 }}
            contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '8px', color: '#f4f4f5' }}
            itemStyle={{ color: '#818cf8' }}
            formatter={(value: number) => [formatCurrency(value), 'Est. MRR']}
          />
          <Bar dataKey="mrr" radius={[4, 4, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={index === data.length - 1 ? '#818cf8' : '#4f46e5'} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
