import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, Loader2, Sparkles } from 'lucide-react';
import { cn } from '../lib/utils';

interface IdeaInputFormProps {
  onSubmit: (data: { skills: string; interest: string; audience: string; problems: string }) => void;
  isLoading: boolean;
}

export const IdeaInputForm: React.FC<IdeaInputFormProps> = ({ onSubmit, isLoading }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    skills: '',
    interest: '',
    audience: '',
    problems: ''
  });

  const handleNext = () => {
    if (step < 4) setStep(step + 1);
    else onSubmit(formData);
  };

  const isStepValid = () => {
    switch (step) {
      case 1: return formData.skills.trim().length > 3;
      case 2: return formData.interest.trim().length > 3;
      case 3: return formData.audience.trim().length > 3;
      case 4: return formData.problems.trim().length > 3;
      default: return false;
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-zinc-900 border border-zinc-800 rounded-2xl p-8 shadow-2xl">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-xl font-semibold text-zinc-100 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-indigo-400" />
          Generate SaaS Ideas
        </h2>
        <div className="flex gap-2">
          {[1, 2, 3, 4].map((s) => (
            <div
              key={s}
              className={cn(
                "w-12 h-1.5 rounded-full transition-colors duration-300",
                s <= step ? "bg-indigo-500" : "bg-zinc-800"
              )}
            />
          ))}
        </div>
      </div>

      <div className="relative min-h-[200px]">
        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="absolute inset-0"
            >
              <label className="block text-sm font-medium text-zinc-400 mb-2">What are your core skills?</label>
              <p className="text-xs text-zinc-500 mb-4">e.g., Full-stack development, marketing, data science, design.</p>
              <textarea
                autoFocus
                value={formData.skills}
                onChange={(e) => setFormData({ ...formData, skills: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-4 text-zinc-100 focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 outline-none resize-none h-32"
                placeholder="I am a React developer with experience in Node.js..."
              />
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="absolute inset-0"
            >
              <label className="block text-sm font-medium text-zinc-400 mb-2">What industries or topics interest you?</label>
              <p className="text-xs text-zinc-500 mb-4">e.g., Real estate, creator economy, fitness, developer tools.</p>
              <textarea
                autoFocus
                value={formData.interest}
                onChange={(e) => setFormData({ ...formData, interest: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-4 text-zinc-100 focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 outline-none resize-none h-32"
                placeholder="I'm really interested in the creator economy and productivity tools..."
              />
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="absolute inset-0"
            >
              <label className="block text-sm font-medium text-zinc-400 mb-2">Who is your target audience?</label>
              <p className="text-xs text-zinc-500 mb-4">e.g., Freelance designers, small agency owners, indie hackers.</p>
              <textarea
                autoFocus
                value={formData.audience}
                onChange={(e) => setFormData({ ...formData, audience: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-4 text-zinc-100 focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 outline-none resize-none h-32"
                placeholder="Independent content creators making $50k-$100k/year..."
              />
            </motion.div>
          )}

          {step === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="absolute inset-0"
            >
              <label className="block text-sm font-medium text-zinc-400 mb-2">What specific problems have you noticed?</label>
              <p className="text-xs text-zinc-500 mb-4">e.g., Managing sponsorships is messy, tracking analytics across platforms is hard.</p>
              <textarea
                autoFocus
                value={formData.problems}
                onChange={(e) => setFormData({ ...formData, problems: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-4 text-zinc-100 focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 outline-none resize-none h-32"
                placeholder="They struggle to manage their sponsorship pipelines and negotiate rates..."
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="mt-8 flex justify-between items-center">
        {step > 1 ? (
          <button
            onClick={() => setStep(step - 1)}
            className="text-sm font-medium text-zinc-400 hover:text-zinc-200 transition-colors px-4 py-2"
          >
            Back
          </button>
        ) : (
          <div />
        )}
        
        <button
          onClick={handleNext}
          disabled={!isStepValid() || isLoading}
          className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-zinc-800 disabled:text-zinc-500 text-white rounded-xl py-2.5 px-6 font-medium transition-colors flex items-center gap-2"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Analyzing Market...
            </>
          ) : step === 4 ? (
            <>
              Generate Ideas
              <Sparkles className="w-4 h-4" />
            </>
          ) : (
            <>
              Next Step
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </div>
  );
}
