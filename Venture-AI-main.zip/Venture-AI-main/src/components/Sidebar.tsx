import { NavLink } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { logOut } from '../firebase';
import { LayoutDashboard, Bookmark, Settings, LogOut, Sparkles, Zap } from 'lucide-react';
import { cn } from '../lib/utils';

export function Sidebar() {
  const { user, subscriptionTier } = useAuth();

  return (
    <aside className="w-64 bg-zinc-900 border-r border-zinc-800 flex flex-col h-full">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 bg-indigo-500/20 rounded-lg flex items-center justify-center border border-indigo-500/30">
          <Sparkles className="w-4 h-4 text-indigo-400" />
        </div>
        <span className="font-semibold text-lg tracking-tight text-zinc-100">VentureAI</span>
      </div>

      <nav className="flex-1 px-4 space-y-1">
        <NavLink
          to="/"
          className={({ isActive }) =>
            cn(
              "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
              isActive ? "bg-zinc-800 text-zinc-100" : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50"
            )
          }
        >
          <LayoutDashboard className="w-4 h-4" />
          Generate Ideas
        </NavLink>
        <NavLink
          to="/saved"
          className={({ isActive }) =>
            cn(
              "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
              isActive ? "bg-zinc-800 text-zinc-100" : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50"
            )
          }
        >
          <Bookmark className="w-4 h-4" />
          Saved Ideas
        </NavLink>
        <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50 transition-colors">
          <Settings className="w-4 h-4" />
          Settings
        </button>
      </nav>

      <div className="p-4 mt-auto">
        <div className="bg-zinc-950 rounded-xl p-4 border border-zinc-800 mb-4">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <span className="text-sm font-medium text-zinc-200">
              {subscriptionTier === 'pro' ? 'Pro Plan' : 'Free Plan'}
            </span>
          </div>
          <p className="text-xs text-zinc-500 mb-3">
            {subscriptionTier === 'pro' ? 'Unlimited ideas & deep analytics.' : '3 ideas per month. Upgrade for more.'}
          </p>
          {subscriptionTier === 'free' && (
            <button className="w-full bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium py-2 rounded-lg transition-colors">
              Upgrade to Pro
            </button>
          )}
        </div>

        <div className="flex items-center gap-3 px-3 py-2">
          <img src={user?.photoURL || ''} alt="User" className="w-8 h-8 rounded-full bg-zinc-800" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-zinc-200 truncate">{user?.displayName}</p>
          </div>
          <button onClick={logOut} className="text-zinc-500 hover:text-zinc-300">
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
}
