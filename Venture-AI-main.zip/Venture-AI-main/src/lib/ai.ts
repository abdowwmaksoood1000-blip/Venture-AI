import { GoogleGenAI, Type } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface GeneratedIdea {
  title: string;
  pitch: string;
  problem: string;
  solution: string;
  monetization: string;
  targetAudience: string;
  metrics: {
    demand: number;
    competition: number;
    feasibility: number;
    overall: number;
  };
  financials: {
    mrrLow: number;
    mrrHigh: number;
    arr: number;
    pricing: number;
    tam: number;
  };
}

export async function generateSaaSIdeas(skills: string, interest: string, audience: string, problems: string): Promise<GeneratedIdea[]> {
  const prompt = `
Act as a Venture Capitalist and Market Analyst. Based on the following user inputs:
- Skills: ${skills}
- Interests: ${interest}
- Target Audience: ${audience}
- Problem Space: ${problems}

Generate 3 unique, highly actionable SaaS ideas tailored for a solo founder.

For each idea, provide:
1. Title & One-Line Pitch
2. Problem Statement (Specific pain point)
3. Solution (Core feature set)
4. Monetization Model (Subscription, Usage-based, etc.)
5. Target Audience (Specific niche)

Then, analyze the market for each idea:
1. Demand Score (0-100): Based on search intent and problem urgency.
2. Competition Score (0-100): Based on existing solutions (Low score = High competition).
3. Feasibility Score (0-100): Based on no-code/AI buildability for a solo founder.
4. Overall Score (0-100): Average of the above.
5. Market Data: Estimate Total Addressable Market (TAM) size in number of potential users/businesses.

Finally, calculate financial projections using this exact logic:
- Pricing: Suggest industry-standard monthly pricing (e.g., $29/mo for B2B, $9/mo for B2C).
- MRR Low: Calculate exactly as (TAM * 0.005 * Pricing)
- MRR High: Calculate exactly as (TAM * 0.02 * Pricing)
- ARR: Calculate exactly as (MRR Low * 12)

Return the response as a JSON array of 3 objects matching the schema.
`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.1-pro-preview',
    contents: prompt,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            pitch: { type: Type.STRING },
            problem: { type: Type.STRING },
            solution: { type: Type.STRING },
            monetization: { type: Type.STRING },
            targetAudience: { type: Type.STRING },
            metrics: {
              type: Type.OBJECT,
              properties: {
                demand: { type: Type.NUMBER },
                competition: { type: Type.NUMBER },
                feasibility: { type: Type.NUMBER },
                overall: { type: Type.NUMBER }
              },
              required: ['demand', 'competition', 'feasibility', 'overall']
            },
            financials: {
              type: Type.OBJECT,
              properties: {
                mrrLow: { type: Type.NUMBER },
                mrrHigh: { type: Type.NUMBER },
                arr: { type: Type.NUMBER },
                pricing: { type: Type.NUMBER },
                tam: { type: Type.NUMBER }
              },
              required: ['mrrLow', 'mrrHigh', 'arr', 'pricing', 'tam']
            }
          },
          required: ['title', 'pitch', 'problem', 'solution', 'monetization', 'targetAudience', 'metrics', 'financials']
        }
      }
    }
  });

  const text = response.text;
  if (!text) {
    throw new Error('No response from AI');
  }

  return JSON.parse(text) as GeneratedIdea[];
}
